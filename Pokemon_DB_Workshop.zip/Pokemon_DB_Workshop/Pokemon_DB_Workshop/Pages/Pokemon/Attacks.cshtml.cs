using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Pokemon_DB_Workshop.Pages.Pokemon
{
    public class AttacksModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
