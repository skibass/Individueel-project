using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Umovie.Pages.ForYou
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
